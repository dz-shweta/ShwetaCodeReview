import { LightningElement, track, wire } from 'lwc';
import leftIcon from '@salesforce/resourceUrl/leftIcon';
import filterIcon from '@salesforce/resourceUrl/filterIcon';
import dateIcon from '@salesforce/resourceUrl/dateIcon';
import { NavigationMixin } from 'lightning/navigation';

import getUserBookmarks from '@salesforce/apex/JobBoardController.getUserBookmarks';
import saveBookmark from '@salesforce/apex/JobBoardController.saveBookmark';
import removeBookmark from '@salesforce/apex/JobBoardController.removeBookmark';
import getJobBoardPosts from '@salesforce/apex/JobBoardController.getJobBoardPosts';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import isGuest from '@salesforce/user/isGuest';
import getMyPostedJobs from '@salesforce/apex/JobBoardController.getMyPostedJobs';

export default class JobBoard extends NavigationMixin(LightningElement) {

    leftIcon = leftIcon;
    filterIcon = filterIcon;
    dateIcon = dateIcon;
    isGuestUser = isGuest;

    @track showFilters = false;
    @track showJobType = true;
    @track showNoResults = false;
    @track savedJobs = [];
    @track activeTab = 'company';
    @track bookmarkedJobIds = [];
    @track sortBy = 'newest'; // default
    @track postedJobs = [];

    filters = {
        country: '',
        state: '',
        role: '',
        jobTypes: []
    };

    pageSize = 10;
    @track page = 1;
    @track totalPages = 1;

    @track allJobs = [];
    @track jobs = [];

    get jobTypeArrow() {
        return this.showJobType ? '▾' : '▸';
    }


    /* =====================================================================================
       NEW — Your Job Fetch Logic Added Here
    ========================================================================================*/

   @wire(getJobBoardPosts)
wiredJobs({ data, error }) {
    
    if (data) {
        this.allJobs = data.map(job => ({
            id: job.Id,
            logo: this.getInitials(job.Company__r?.Name),
            title: job.Job_Title__c ,
            company: job.Company__r?.Name ,
            state: job.State__c ,
            country: job.Country__c ,
            location: `${job.State__c}  ${job.Country__c}`,
            Employee: job.Employee__c ,
            description: job.Job_Description__c || '',
            createdDate: job.CreatedDate,
            date: this.getRelativeTime(job.CreatedDate),
            isSaved: false
        }));

        this.syncBookmarks();
        this.totalPages = Math.ceil(this.allJobs.length / this.pageSize);
        this.setPageData();
    }
}
    @wire(getMyPostedJobs)
    wiredPostedJobs({ data, error }) {
        if (data) {
            this.postedJobs = data.map(job => ({
                id: job.Id,
                logo: this.getInitials(job.Company__r?.Name),
                title: job.Job_Title__c,
                company: job.Company__r?.Name,
                state: job.State__c,
                country: job.Country__c,
                Employee: job.Employee__c,
                createdDate: job.CreatedDate,
                date: this.getRelativeTime(job.CreatedDate),
                isSaved: false
            }));
        } else if (error) {
            console.error('Posted jobs error', error);
        }
    }



       @wire(getUserBookmarks)
       wiredBookmarks({ data, error }) {
        if (data) {
            this.bookmarkedJobIds = data;
            this.syncBookmarks();
        } else if (error) {
            console.error('Bookmark load error', error);
        }
    }

    getRelativeTime(dateString) {
        const jobDate = new Date(dateString);
        const now = new Date();

        const diffMs = now - jobDate;
        const diffSeconds = Math.floor(diffMs / 1000);
        const diffMinutes = Math.floor(diffSeconds / 60);
        const diffHours = Math.floor(diffMinutes / 60);
        const diffDays = Math.floor(diffHours / 24);

        if (diffSeconds < 60) return "Just now";
        if (diffMinutes < 60) return `${diffMinutes} min ago`;
        if (diffHours < 24) return `${diffHours} hours ago`;
        if (diffDays < 7) return `${diffDays} days ago`;

        // For older posts — show date
        return jobDate.toLocaleDateString();
    }
    connectedCallback() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('saved') === 'true') {
        this.showSavedTab();
    }
}



    /* ===================================================================================== */


    setPageData() {
    let sourceList;

    if (this.activeTab === 'company') {
        sourceList = this.allJobs;
    } else if (this.activeTab === 'saved') {
        sourceList = this.savedJobs;
    } else if (this.activeTab === 'posted') {
        sourceList = this.postedJobs;
    }

    sourceList = this.sortJobs(sourceList);

    let start = (this.page - 1) * this.pageSize;
    let end = start + this.pageSize;

    this.jobs = sourceList.slice(start, end);
}



    nextPage() {
        if (this.page < this.totalPages) {
            this.page++;
            this.setPageData();
        }
    }

    prevPage() {
        if (this.page > 1) {
            this.page--;
            this.setPageData();
        }
    }
    get countryOptions() {
    return [...new Set(this.jobs.map(j => j.country))];
    }
   
    get stateOptions() {
    return [...new Set(this.jobs.map(j => j.state))];
    }


    openFilters() { this.showFilters = true; }
    closeFilters() { this.showFilters = false; }
    toggleJobType() { this.showJobType = !this.showJobType; }

    clearAll() {
    this.filters = {
        country: '',
        state: '',
        role: '',
        jobTypes: []
    };

    // Reset ONLY filter dropdowns
    this.template.querySelectorAll('.filter-select')
        .forEach(sel => sel.value = '');

    // Reset checkboxes
    this.template.querySelectorAll('input[type="checkbox"]')
        .forEach(cb => cb.checked = false);

    // Reset sorting
    this.sortBy = 'newest';
    const sortSelect = this.template.querySelector('.sort-row select');
    if (sortSelect) sortSelect.value = 'newest';

    this.page = 1;
    this.totalPages = Math.ceil(this.allJobs.length / this.pageSize);
    this.setPageData();
    this.closeFilters();
}


    applyFilters() {
        let filtered = [...this.allJobs];

        if (this.filters.country) {
            filtered = filtered.filter(job =>
                job.country?.toLowerCase().includes(this.filters.country.toLowerCase())
            );
        }

        if (this.filters.state) {
            filtered = filtered.filter(job =>
                job.location.toLowerCase().includes(this.filters.state.toLowerCase())
            );
        }

        if (this.filters.role && this.filters.role !== 'Select a Role') {
            filtered = filtered.filter(job =>
                job.title.toLowerCase().includes(this.filters.role.toLowerCase())
            );
        }

            if (this.filters.jobTypes.length > 0) {
            filtered = filtered.filter(job =>
                this.filters.jobTypes.includes(job.Employee)
            );
        }

        if (this.searchValue) {
            filtered = filtered.filter(job =>
                job.company?.toLowerCase().includes(this.searchValue) ||
                job.location?.toLowerCase().includes(this.searchValue) ||
                job.country?.toLowerCase().includes(this.searchValue) ||
                job.title?.toLowerCase().includes(this.searchValue)
            );
        }

        this.page = 1;
        this.totalPages = Math.ceil(filtered.length / this.pageSize);
        this.setPageDataFiltered(filtered);
        this.showNoResults = filtered.length === 0;

        this.closeFilters();
    }

    handlePostJob() {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: { url: '/jobpost' }
        });
    }

    get isPrevDisabled() { return this.page === 1; }
    get isNextDisabled() { return this.page === this.totalPages; }

    handleSearch(event) {
        this.searchValue = event.target.value.toLowerCase();

        if (this.searchValue === '') {
            this.page = 1;
            this.totalPages = Math.ceil(this.allJobs.length / this.pageSize);
            this.setPageData();
            return;
        }

        let filtered = this.allJobs.filter(job =>
            job.company?.toLowerCase().includes(this.searchValue) ||
            job.location?.toLowerCase().includes(this.searchValue) ||
            job.country?.toLowerCase().includes(this.searchValue) ||
            job.title?.toLowerCase().includes(this.searchValue)
        );

        this.jobs = filtered;
        this.totalPages = Math.ceil(filtered.length / this.pageSize);
        this.page = 1;
        this.setPageDataFiltered(filtered);
    }

    setPageDataFiltered(filteredList) {
        let start = (this.page - 1) * this.pageSize;
        let end = start + this.pageSize;
        this.jobs = filteredList.slice(start, end);
    }

    handleFilterChange(event) {
        const field = event.target.dataset.field;
        this.filters[field] = event.target.value;
    }

    handleJobTypeChange(event) {
        const type = event.target.value;

        if (event.target.checked) {
            this.filters.jobTypes.push(type);
        } else {
            this.filters.jobTypes = this.filters.jobTypes.filter(t => t !== type);
        }
    }

    handleBookmark(event) {
    const jobId = event.currentTarget.dataset.id;

    const index = this.allJobs.findIndex(j => j.id === jobId);
    if (index === -1) return;

    const job = this.allJobs[index];
    const action = job.isSaved ? removeBookmark : saveBookmark;

    action({ jobId })
        .then(() => {
            job.isSaved = !job.isSaved;
            job.bookmarkFill = job.isSaved ? '#1E3A8A' : 'none';

            if (job.isSaved) {
                this.bookmarkedJobIds = [...this.bookmarkedJobIds, jobId];

                // ✅ SUCCESS STICKY TOAST (GREEN)
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Job has been bookmarked successfully.',
                        variant: 'success',
                        mode: 'sticky'
                    })
                );

            } else {
                this.bookmarkedJobIds =
                    this.bookmarkedJobIds.filter(id => id !== jobId);

                // Optional: info toast for remove
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Removed',
                        message: 'Job removed from saved list.',
                        variant: 'info',
                        mode: 'dismissable'
                    })
                );
            }

            this.savedJobs = this.allJobs.filter(j => j.isSaved);
            this.allJobs = [...this.allJobs]; // force re-render
            this.setPageData();
        })
        .catch(error => {
            console.error('Bookmark error:', error);

            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: error.body?.message || 'Unable to save bookmark',
                    variant: 'error',
                    mode: 'sticky'
                })
            );
        });
    }

    showCompanyTab() {
        this.activeTab = 'company';
        this.page = 1;
        this.totalPages = Math.ceil(this.allJobs.length / this.pageSize);
        this.setPageData();
    }

    showSavedTab() {
        this.activeTab = 'saved';
        this.page = 1;
        this.totalPages = Math.ceil(this.savedJobs.length / this.pageSize);
        this.setPageDataSaved();
    }

    setPageDataSaved() {
        let start = (this.page - 1) * this.pageSize;
        let end = start + this.pageSize;
        this.jobs = this.savedJobs.slice(start, end);
    }

    get companyTabClass() {
        return this.activeTab === 'company' ? 'tab active' : 'tab';
    }

    get savedTabClass() {
        return this.activeTab === 'saved' ? 'tab active' : 'tab';
    }
    getInitials(name) {
    if (!name) return "NA";

    return name
        .trim()
        .split(/\s+/)                 // split by space(s)
        .map(word => word[0])         // take first letter of each word
        .join('')                     // join together
        .toUpperCase();               // convert to uppercase
}
    syncBookmarks() {
        if (!this.allJobs.length || !this.bookmarkedJobIds.length) return;

        this.allJobs = this.allJobs.map(job => ({
            ...job,
            isSaved: this.bookmarkedJobIds.includes(job.id),
            bookmarkFill: this.bookmarkedJobIds.includes(job.id)
                ? '#1E3A8A'
                : 'none'
        }));

        this.savedJobs = this.allJobs.filter(j => j.isSaved);
        this.setPageData();
    }
    sortJobs(list) {
        return [...list].sort((a, b) => {
            const dateA = new Date(a.createdDate);
            const dateB = new Date(b.createdDate);

            return this.sortBy === 'newest'
                ? dateB - dateA   // Newest first
                : dateA - dateB;  // Oldest first
        });
    }

    handleSortChange(event) {
        this.sortBy = event.target.value;
        this.page = 1;
        this.setPageData();
    }

    openJobDetail(event) {
        const jobId = event.currentTarget.dataset.id;
        const jobDateText = event.currentTarget.dataset.date;
        sessionStorage.setItem('selectedJobPostedDate', jobDateText);

        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: `/job-description?jobId=${jobId}`
            }
        });
    }

    showPostedTab() {
        this.activeTab = 'posted';
        this.page = 1;
        this.totalPages = Math.ceil(this.postedJobs.length / this.pageSize);
        this.setPageDataPosted();
    }

    setPageDataPosted() {
    let start = (this.page - 1) * this.pageSize;
    let end = start + this.pageSize;
    this.jobs = this.postedJobs.slice(start, end);
}

    get postedTabClass() {
        return this.activeTab === 'posted' ? 'tab active' : 'tab';
    }
get isAuthorizedUser() {
    return !this.isGuestUser;
}



}